#include "FormWindow.h"

FormWindow::FormWindow(void)
{
    mbRun = false;
    mpWindow = NULL;
    mpForm = NULL;
    mpCB = NULL;
}

FormWindow::~FormWindow(void)
{
    Destroy();
}

void FormWindow::SetAttribute(WindowAttribute &windowAttribute)
{
    mWindowAttribute = windowAttribute;
}

bool FormWindow::SetField(const char *sField, int nFieldMaxLen, int nFieldHeight)
{
    if (!stdscr)
        return false;
    if (mpForm)
        return false;
    if (mpWindow)
        return false;
    if (!mpFields.empty())
        return false;

    _FIELD stField;
    memset(&stField, 0x00, sizeof(stField));
    stField.sField = sField;
    stField.nFieldMaxLen = nFieldMaxLen;
    stField.nFieldHeight = nFieldHeight;
    mstFields.push_back(stField);
    return true;
}

bool FormWindow::CreateFields(void)
{
    if (!stdscr)
        return false;
    if (mpForm)
        return false;
    if (mpWindow)
        return false;
    if (mstFields.empty())
        return false;

    int nOldY = 0;
    for (std::vector<_FIELD>::size_type nField = 0; nField < mstFields.size(); nField++)
    {
        // 높이, 넓이, 시작 Y, 시작 X, Offset, 추가버퍼
        int nStartY = (nField < 1 ? nOldY : nOldY + mstFields[nField - 1].nFieldHeight);
        FIELD *pField = new_field(mstFields[nField].nFieldHeight, mstFields[nField].nFieldMaxLen,
                                  nStartY, strlen(mstFields[nField].sField) + 1,
                                  0, 0);
        if (!pField)
            continue;

        mpFields.push_back(pField);
        nOldY = nStartY;
    }

    mpFields.push_back(NULL);
    return true;
}

const char *FormWindow::GetFieldBuffer(int nField, char *sField)
{
    if (mpFields.empty())
        return NULL;

    sprintf(sField, "%s", field_buffer(mpFields[nField], 0));
    iTrim(sField);
    return sField;
}

/**
 * @brief
 * XXX Field Options
 * O_VISIBLE
 * O_AUTOSKIP
 * O_NULLOK
 */
void FormWindow::SetFieldOption(int nField, bool bIsOn, unsigned int nFieldOptions)
{
    if (mpFields.empty())
        return;

    if (bIsOn)
        field_opts_on(mpFields[nField], nFieldOptions);
    else
        field_opts_off(mpFields[nField], nFieldOptions);
}

void FormWindow::SetFieldsOption(bool bIsOn, unsigned int nFieldOptions)
{
    if (mpFields.empty())
        return;

    for (std::vector<FIELD *>::size_type nField = 0; nField < mpFields.size(); nField++)
    {
        if (bIsOn)
            field_opts_on(mpFields[nField], nFieldOptions);
        else
            field_opts_off(mpFields[nField], nFieldOptions);
    }
}

void FormWindow::SetFieldDefaultValue(int nField, const char *sBuffer)
{
    if (mpFields.empty())
        return;

    set_field_buffer(mpFields[nField], 0, sBuffer);
}

void FormWindow::SetFieldColor(int nField, short nForgroundColor, short nBackgroundColor)
{
    if (mpFields.empty())
        return;

    Painter::GetInstance()->SetFieldColor(mpFields[nField], nForgroundColor, nBackgroundColor);
}

void FormWindow::SetFieldsColor(short nForgroundColor, short nBackgroundColor)
{
    if (mpFields.empty())
        return;

    for (std::vector<FIELD *>::size_type nField = 0; nField < mpFields.size(); nField++)
        Painter::GetInstance()->SetFieldColor(mpFields[nField], nForgroundColor, nBackgroundColor);
}

/**
 * @brief
 * XXX nFiledOption -> Curses Option Use
 * A_NORMAL        Normal display (no highlight)
 * A_STANDOUT      Best highlighting mode of the terminal.
 * A_UNDERLINE     Underlining
 * A_REVERSE       Reverse video
 * A_BLINK         Blinking
 * A_DIM           Half bright
 * A_BOLD          Extra bright or bold
 * A_PROTECT       Protected mode
 * A_INVIS         Invisible or blank mode
 * A_ALTCHARSET    Alternate character set
 * A_CHARTEXT      Bit-mask to extract a character
 * COLOR_PAIR(n)   Color-pair number n
 * example) A_NORMAL | A_BLINK
 */
void FormWindow::SetFieldBack(int nField, unsigned int nFieldBack)
{
    if (mpFields.empty())
        return;

    set_field_back(mpFields[nField], nFieldBack);
}

void FormWindow::SetFieldsBack(unsigned int nFieldBack)
{
    if (mpFields.empty())
        return;

    for (std::vector<FIELD *>::size_type nField = 0; nField < mpFields.size(); nField++)
        set_field_back(mpFields[nField], nFieldBack);
}

void FormWindow::SetFieldTypeAlpha(int nField, int nWidth)
{
    if (mpFields.empty())
        return;

    set_field_type(mpFields[nField], TYPE_ALPHA, nWidth);
}

void FormWindow::SetFieldTypeAlNum(int nField, int nWidth)
{
    if (mpFields.empty())
        return;

    set_field_type(mpFields[nField], TYPE_ALNUM, nWidth);
}

void FormWindow::SetFieldTypeInt(int nField, int nPadding, int nValidMin, int nValidMax)
{
    if (mpFields.empty())
        return;

    set_field_type(mpFields[nField], TYPE_INTEGER, nPadding, nValidMin, nValidMax);
}

void FormWindow::SetFieldTypeRegexp(int nField, char *sRegexp)
{
    if (mpFields.empty())
        return;

    set_field_type(mpFields[nField], TYPE_REGEXP, sRegexp);
}

void FormWindow::SetFieldTypeIpv4(int nField)
{
    if (mpFields.empty())
        return;

    set_field_type(mpFields[nField], TYPE_IPV4);
}

bool FormWindow::CreateForm(void)
{
    if (mpFields.empty())
        return false;

    mpForm = new_form(mpFields.data());
    if (!mpForm)
        return false;

    return true;
}

bool FormWindow::CreateWindow(void)
{
    if (!stdscr)
        return false;
    if (mpFields.empty())
        return false;
    if (!mpForm)
        return false;
    if (mpWindow)
        return false;

    int nFormX, nFormY;
    scale_form(mpForm, &nFormY, &nFormX);

    mpWindow = newwin(mWindowAttribute.GetY(), mWindowAttribute.GetX(), mWindowAttribute.GetBeginY(), mWindowAttribute.GetBeginX());
    if (!mpWindow)
        return false;

    Painter::GetInstance()->SetWindowColor(mpWindow, mWindowAttribute.GetForgroundColor(), mWindowAttribute.GetBackgroundColor());

    set_form_win(mpForm, mpWindow);
    set_form_sub(mpForm, derwin(mpWindow, nFormY, nFormX, mWindowAttribute.GetMarginX(), mWindowAttribute.GetMarginY()));

    WINDOW *pSubWindow = form_sub(mpForm);
    if (!pSubWindow)
        return false;

    post_form(mpForm);

    int nOldY = 0;
    for (std::vector<_FIELD>::size_type nField = 0; nField < mstFields.size(); nField++)
    {
        int nStartY = (nField < 1 ? nOldY : nOldY + mstFields[nField - 1].nFieldHeight);
        wattron(mpWindow, A_BOLD);
        mvwaddnstr(pSubWindow, nStartY, 1, mstFields[nField].sField, strlen(mstFields[nField].sField) + 1);
        wattroff(mpWindow, A_BOLD);
        nOldY = nStartY;
    }
    wrefresh(pSubWindow);

    if (mWindowAttribute.IsBox())
        box(mpWindow, 0, 0);

    wrefresh(mpWindow);
    return true;
}

void FormWindow::Destroy(void)
{
    mbRun = false;
    DestroyFields();
    DestroyForm();
    DestroyWindow();
}

void FormWindow::DestroyFields(void)
{
    for (std::vector<FIELD *>::size_type nField = 0; nField < mpFields.size(); nField++)
    {
        if (!mpFields[nField])
            continue;

        free_field(mpFields[nField]);
        mpFields[nField] = NULL;
    }

    mstFields.clear();
    mpFields.clear();
}

void FormWindow::DestroyForm(void)
{
    if (!mpForm)
        return;

    unpost_form(mpForm);
    free_form(mpForm);
    mpForm = NULL;
}

void FormWindow::DestroyWindow(void)
{
    if (!mpWindow)
        return;

    if (mWindowAttribute.IsBox())
        wborder(mpWindow, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ');

    werase(mpWindow);
    delwin(mpWindow);
    mpWindow = NULL;
}

void FormWindow::SetRun(bool bRun)
{
    mbRun = bRun;
}

bool FormWindow::IsRun(void)
{
    return mbRun;
}

void FormWindow::Run(pFormCB pFunction)
{
    if (!stdscr)
        return;
    if (!mpWindow)
        return;
    if (!mpForm)
        return;

    keypad(mpWindow, TRUE);
    mpCB = std::move(pFunction);
    mbRun = true;

    while (mbRun)
    {
        int nChar = wgetch(mpWindow);
        form_driver(mpForm, REQ_VALIDATION);
        FIELD *pCurrentField = current_field(mpForm);
        if (!pCurrentField)
            continue;

        char sInput[MAXLEN_FEILDNAME];
        memset(sInput, 0x00, sizeof(sInput));
        snprintf(sInput, MAXLEN_FEILDNAME, "%s", field_buffer(pCurrentField, 0));
        iTrim(sInput);

        mpCB(field_index(pCurrentField), nChar, sInput);
        DefaultKeyAction(nChar);
        wrefresh(mpWindow);
    }
}

void FormWindow::DefaultKeyAction(int nChar)
{
    switch (nChar)
    {
    case KEY_LEFT:
        form_driver(mpForm, REQ_PREV_CHAR);
        break;
    case KEY_RIGHT:
        form_driver(mpForm, REQ_NEXT_CHAR);
        break;
    case KEY_UP:
        form_driver(mpForm, REQ_PREV_FIELD);
        form_driver(mpForm, REQ_END_LINE);
        break;
    case KEY_DOWN:
        form_driver(mpForm, REQ_NEXT_FIELD);
        form_driver(mpForm, REQ_END_LINE);
        break;
    case KEY_HOME:
        form_driver(mpForm, REQ_BEG_LINE);
        break;
    case KEY_END:
        form_driver(mpForm, REQ_END_LINE);
        break;
    case KEY_BACKSPACE:
        form_driver(mpForm, REQ_DEL_PREV);
        break;
    case KEY_DC:
        form_driver(mpForm, REQ_DEL_LINE);
        break;
    default:
        form_driver(mpForm, nChar);
        break;
    }
}

void FormWindow::DeleteLine(void)
{
    form_driver(mpForm, REQ_DEL_LINE);
}

void FormWindow::MovePrevLine(void)
{
    form_driver(mpForm, REQ_PREV_FIELD);
}

void FormWindow::MoveNextLine(void)
{
    form_driver(mpForm, REQ_NEXT_FIELD);
}
