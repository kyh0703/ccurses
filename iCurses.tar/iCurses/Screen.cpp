#include "Screen.h"

Screen::Screen(void)
{
    mpWindow = NULL;
    setlocale(LC_ALL, "ko_KR.utf8");
}

Screen::~Screen(void)
{
    DestroyScreen();
}

bool Screen::CreateScreen(void)
{
    mpWindow = initscr();
    if (!mpWindow)
        return false;

    if (cbreak() != OK)
    {
        DestroyScreen();
        return false;
    }

    if (noecho() != OK)
    {
        DestroyScreen();
        return false;
    }

    refresh();
    return true;
}

void Screen::DestroyScreen(void)
{
    if (!mpWindow)
        return;

    erase();
    endwin();
    mpWindow = NULL;
}

void Screen::GetXY(int &nScreenX, int &nScreenY)
{
    if (!mpWindow)
        return;

    getmaxyx(mpWindow, nScreenX, nScreenY);
}
