#pragma once
#include <ncurses.h>
#include <form.h>
#include <menu.h>
#include <string.h>

enum
{
    eMenuColorSet_Disable,
    eMenuColorSet_Cursor,
    eMenuColorSet_Default,
};

typedef struct
{
    short nNo;
    short nForgroundColor;
    short nBackgroundColor;
} COLOR_TABLE;

class Painter
{
private:
    Painter(void);
    Painter(const Painter &other);
    ~Painter(void);

public:
    static Painter *GetInstance(void);
    static void DestroyInstance(void);

    bool IsColorSet(short nForgroundColor, short nBackgroundColor);
    short FindIndex(short nForgroundColor, short nBackgroundColor);
    short AppendColorSet(short nForgroundColor, short nBackgroundColor);
    short FindColorSet(short nForgroundColor, short nBackgroundColor);
    bool SetWindowColor(WINDOW *pWindow, short nForgroundColor, short nBackgroundColor);
    bool SetFieldColor(FIELD *pField, short nForgroundColor, short nBackgroundColor);
    bool SetMenuColor(MENU *pMenu, short nType, short nForgroundColor, short nBackgroundColor);

private:
    int mnColorCount;
    COLOR_TABLE mstColorTable[64];
    static Painter *instance;
};
