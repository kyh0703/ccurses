#pragma once
#include <string.h>
#include <vector>
#include <ncurses.h>
#include "Painter.h"
#include "WindowAttribute.h"

/**
 * cTextPosition -> Define Position Value
 * TEXT_NEXT_X
 * TEXT_LEFT_X
 * TEXT_CENTER_X
 * TEXT_RIGHT_X
 * TEXT_NEXT_Y
 * TEXT_TOP_Y
 * TEXT_MIDDLE_Y
 * TEXT_BOTTOM_Y
 * TEXT_FREE_Y
 * example) TEXT_NEXT_X | TEXT_NEXT_Y
 *
 * nTextOption -> Curses Option Use
 * A_NORMAL        Normal display (no highlight)
 * A_STANDOUT      Best highlighting mode of the terminal.
 * A_UNDERLINE     Underlining
 * A_REVERSE       Reverse video
 * A_BLINK         Blinking
 * A_DIM           Half bright
 * A_BOLD          Extra bright or bold
 * A_PROTECT       Protected mode
 * A_INVIS         Invisible or blank mode
 * A_ALTCHARSET    Alternate character set
 * A_CHARTEXT      Bit-mask to extract a character
 * COLOR_PAIR(n)   Color-pair number n
 * example) A_NORMAL | A_BLINK
 */
class BasicWindow
{
public:
    BasicWindow(void);
    virtual ~BasicWindow(void);

    void SetAttribute(WindowAttribute &windowAttribute);
    bool CreateWindow(void);
    void Destroy(void);
    void DestroyWindow(void);
    void Print(unsigned char cTextPosition, unsigned int cTextAttribute, const char *sFormat, ...);
    void GetStartXY(int &nStartX, int &nStartY);
    void GetXY(int &nX, int &nY);
    int GetStringLength(const char *sString);
    

private:
    WINDOW *mpWindow;
    WindowAttribute mWindowAttribute;
};
