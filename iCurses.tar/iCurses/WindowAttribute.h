#pragma once

#include <string.h>
#include <ncurses.h>

enum eTextPosition
{
    TEXT_NULL = 0x00,
    TEXT_NEXT_X = 0x01,
    TEXT_LEFT_X = 0x02,
    TEXT_CENTER_X = 0x04,
    TEXT_RIGHT_X = 0x08,
    TEXT_NEXT_Y = 0x10,
    TEXT_TOP_Y = 0x20,
    TEXT_MIDDLE_Y = 0x40,
    TEXT_BOTTOM_Y = 0x80,
};

class WindowAttribute
{
  private:
    bool mbBoxYn;
    short mnBeginX;
    short mnBeginY;
    short mnLastX;
    short mnLastY;
    short mnX;
    short mnY;
    short mnMarginX;
    short mnMarginY;
    short mnForgroundColor;
    short mnBackgroundColor;

  public:
    WindowAttribute(void) : mbBoxYn(false), mnBeginX(0), mnBeginY(0), mnLastX(0), mnLastY(0), mnX(0), mnY(0),
                            mnMarginX(0), mnMarginY(0), mnForgroundColor(COLOR_WHITE), mnBackgroundColor(COLOR_BLACK)
    {
    }
    ~WindowAttribute(void) {}

    WindowAttribute &operator=(WindowAttribute &Other)
    {
        (*this).SetBoxYn(Other.IsBox());
        (*this).SetBeginX(Other.GetBeginX());
        (*this).SetBeginY(Other.GetBeginY());
        (*this).SetLastX(Other.GetLastX());
        (*this).SetLastY(Other.GetLastY());
        (*this).SetX(Other.GetX());
        (*this).SetY(Other.GetY());
        (*this).SetMarginX(Other.GetMarginX());
        (*this).SetMarginY(Other.GetMarginY());
        (*this).SetForgroundColor(Other.GetForgroundColor());
        (*this).SetBackgroundColor(Other.GetBackgroundColor());
        return *this;
    }

    bool IsBox(void) { return mbBoxYn; }
    short GetBeginX(void) { return mnBeginX; }
    short GetBeginY(void) { return mnBeginY; }
    short GetLastX(void) { return mnLastX; }
    short GetLastY(void) { return mnLastY; }
    short GetX(void) { return mnX; }
    short GetY(void) { return mnY; }
    short GetMarginX(void) { return mnMarginX; }
    short GetMarginY(void) { return mnMarginY; }
    short GetForgroundColor(void) { return mnForgroundColor; }
    short GetBackgroundColor(void) { return mnBackgroundColor; }

    void SetBoxYn(bool bBoxYn) { mbBoxYn = bBoxYn; }
    void SetBeginX(short nBeginX) { mnBeginX = nBeginX; }
    void SetBeginY(short nBeginY) { mnBeginY = nBeginY; }
    void SetLastX(short nLastX) { mnLastX = nLastX; }
    void SetLastY(short nLastY) { mnLastY = nLastY; }
    void SetX(short nX) { mnX = nX; }
    void SetY(short nY) { mnY = nY; }
    void SetMarginX(short nMarginX) { mnMarginX = nMarginX; }
    void SetMarginY(short nMarginY) { mnMarginY = nMarginY; }
    void SetForgroundColor(short nForgroundColor) { mnForgroundColor = nForgroundColor; }
    void SetBackgroundColor(short nBackgroundColor) { mnBackgroundColor = nBackgroundColor; }
};
