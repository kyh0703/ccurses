#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>
#include <ncurses.h>
#include "Painter.h"

class Screen
{
public:
    Screen(void);
    virtual ~Screen(void);

    bool CreateScreen(void);
    void DestroyScreen(void);
    void GetXY(int &nScreenX, int &nScreenY);

private:
    WINDOW *mpWindow;
};
