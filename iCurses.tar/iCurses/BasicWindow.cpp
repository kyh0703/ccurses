#include "BasicWindow.h"

BasicWindow::BasicWindow(void)
{
    mpWindow = NULL;
}

BasicWindow::~BasicWindow(void)
{
    Destroy();
}

void BasicWindow::SetAttribute(WindowAttribute &windowAttribute)
{
    mWindowAttribute = windowAttribute;
}

bool BasicWindow::CreateWindow(void)
{
    if (!stdscr)
        return false;

    if (mpWindow)
        return false;

    mpWindow = newwin(mWindowAttribute.GetY(), mWindowAttribute.GetX(), mWindowAttribute.GetBeginY(), mWindowAttribute.GetBeginX());
    if (!mpWindow)
        return false;

    Painter::GetInstance()->SetWindowColor(mpWindow, mWindowAttribute.GetForgroundColor(), mWindowAttribute.GetBackgroundColor());

    if (mWindowAttribute.IsBox())
        wborder(mpWindow, 0, 0, 0, 0, 0, 0, 0, 0);

    wrefresh(mpWindow);
    return true;
}

void BasicWindow::Destroy(void)
{
    DestroyWindow();
}

void BasicWindow::DestroyWindow(void)
{
    if (!mpWindow)
        return;

    if (mWindowAttribute.IsBox())
        wborder(mpWindow, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ');

    werase(mpWindow);
    delwin(mpWindow);
    mpWindow = NULL;
}

/**
 * @brief Desc Argument
 * cTextPosition -> Define Position Value
 * TEXT_NEXT_X
 * TEXT_LEFT_X
 * TEXT_CENTER_X
 * TEXT_RIGHT_X
 * TEXT_NEXT_Y
 * TEXT_TOP_Y
 * TEXT_MIDDLE_Y
 * TEXT_BOTTOM_Y
 * example) TEXT_NEXT_X | TEXT_NEXT_Y
 *
 * nTextOption -> Curses Option Use
 * A_NORMAL        Normal display (no highlight)
 * A_STANDOUT      Best highlighting mode of the terminal.
 * A_UNDERLINE     Underlining
 * A_REVERSE       Reverse video
 * A_BLINK         Blinking
 * A_DIM           Half bright
 * A_BOLD          Extra bright or bold
 * A_PROTECT       Protected mode
 * A_INVIS         Invisible or blank mode
 * A_ALTCHARSET    Alternate character set
 * A_CHARTEXT      Bit-mask to extract a character
 * COLOR_PAIR(n)   Color-pair number n
 * example) A_NORMAL | A_BLINK
 */
void BasicWindow::Print(unsigned char cTextPosition, unsigned int nTextOption, const char *sFormat, ...)
{
    if (!stdscr)
        return;
    if (!mpWindow)
        return;

    char sText[4096];
    memset(sText, 0x00, sizeof(sText));

    va_list Marker;
    va_start(Marker, sFormat);
    vsnprintf(sText, sizeof(sText), sFormat, Marker);
    va_end(Marker);

    int nXPosition = (mWindowAttribute.IsBox() ? 1 : 0);
    int nYPosition = (mWindowAttribute.IsBox() ? 1 : 0);

    if (cTextPosition & TEXT_NEXT_X)
    {
        nXPosition = mWindowAttribute.GetLastX();
    }
    else if (cTextPosition & TEXT_LEFT_X)
    {
        nXPosition = (mWindowAttribute.IsBox() ? 1 : 0);
    }
    else if (cTextPosition & TEXT_CENTER_X)
    {
        if (mWindowAttribute.IsBox())
            nXPosition = ((mWindowAttribute.GetX() - 2) - GetStringLength(sText)) / 2;
        else
            nXPosition = (mWindowAttribute.GetX() - GetStringLength(sText)) / 2;
    }
    else if (cTextPosition & TEXT_RIGHT_X)
    {
        if (mWindowAttribute.IsBox())
            nXPosition = (mWindowAttribute.GetX() - 1) - GetStringLength(sText);
        else
            nXPosition = mWindowAttribute.GetX() - GetStringLength(sText);
    }

    if (cTextPosition & TEXT_NEXT_Y)
    {
        nYPosition = mWindowAttribute.GetLastY() + 1;
    }
    else if (cTextPosition & TEXT_TOP_Y)
    {
        if (mWindowAttribute.IsBox())
            nYPosition = mWindowAttribute.GetBeginY() + 1;
        else
            nYPosition = mWindowAttribute.GetBeginY();
    }
    else if (cTextPosition & TEXT_MIDDLE_Y)
    {
        if (mWindowAttribute.IsBox())
            nYPosition = (mWindowAttribute.GetY() - 2) / 2;
        else
            nYPosition = mWindowAttribute.GetY() / 2;
    }
    else if (cTextPosition & TEXT_BOTTOM_Y)
    {
        if (mWindowAttribute.IsBox())
            nYPosition = mWindowAttribute.GetY() - 2;
        else
            nYPosition = mWindowAttribute.GetY() - 1;
    }


    wattron(mpWindow, nTextOption);
    mvwprintw(mpWindow, nYPosition, nXPosition, sText);
    wattroff(mpWindow, nTextOption);
    for (int i = 0; sText[i] != 0x00; i++)
    {
        if (sText[i] == '\n')
            nYPosition++;
    }
    mWindowAttribute.SetLastX(nXPosition + GetStringLength(sText));
    mWindowAttribute.SetLastY(nYPosition);
    wrefresh(mpWindow);
}

void BasicWindow::GetStartXY(int &nStartX, int &nStartY)
{
    if (!mpWindow)
        return;

    getbegyx(mpWindow, nStartY, nStartX);
}

void BasicWindow::GetXY(int &nX, int &nY)
{
    if (!mpWindow)
        return;

    nX = getmaxx(mpWindow);
    nY = getmaxy(mpWindow);
}

int BasicWindow::GetStringLength(const char *sString)
{
    int nIdx = 0;
    int nCount = 0;
    
    while (sString[nIdx])
    {
        if (sString[nIdx] & 0x80)
            nIdx+=2;

        nCount++;
        nIdx++;
    }

    return nCount;
}
