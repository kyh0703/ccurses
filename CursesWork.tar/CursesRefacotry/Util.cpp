#include "Util.h"

Util::Util(void)
{
}

Util::~Util(void)
{
}