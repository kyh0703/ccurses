#pragma once
#include <ncurses.h>
#include <string>
#include <vector>
#include "Curses.h"

using namespace std;

struct Position
{
    short h, w, x, y;
};

struct Attribute
{
    WINDOW *pWin;
    Position pos;
    bool hasbox;
    vector<string> items;
};

class Widget : public Curses
{
public:
    Widget();
    virtual ~Widget();

public:
    virtual bool Draw(void) = 0;

public:
    Attribute mAttr;
};

class Basic : public Widget
{
public:
    bool Draw(void) override;
};

class HorisonMenu : public Widget
{
public:
    bool Draw(void) override;
};
