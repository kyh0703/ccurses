#include "Curses.h"
#include "Widget.h"

Widget::Widget()
{
}

Widget::~Widget()
{
}

bool Basic::Draw(void)
{
    if (!CreateWin(mAttr.pos.h, mAttr.pos.w,
                   mAttr.pos.x, mAttr.pos.y))
        return false;

    if (mAttr.hasbox)
        CreateBox();
    return true;
}

bool HorisonMenu::Draw(void)
{
    if (!CreateWin(mAttr.pos.h, mAttr.pos.w,
                   mAttr.pos.x, mAttr.pos.y))
        return false;

    return true;
}