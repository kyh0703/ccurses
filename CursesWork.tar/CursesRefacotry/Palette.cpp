#include "Palette.h"

Palette::Palette()
{
}

Palette::~Palette()
{
    erase();
    endwin();
}

void Palette::Init()
{
    initscr();
    clear();
    cbreak();
    noecho();
    keypad(stdscr, TRUE);

    setlocale(LC_ALL, "ko_KR.utf8");
    mousemask(ALL_MOUSE_EVENTS, NULL);
    refresh();
}

void Palette::AttachWidget(Widget *pWidget)
{
    mWidgets.push_back(pWidget);
}

bool Palette::DrawWidget()
{
    vector<Widget *>::iterator iter;
    for (iter = mWidgets.begin(); iter != mWidgets.end(); ++iter)
    {
        (*iter)->Draw();
    }
    return true;
}