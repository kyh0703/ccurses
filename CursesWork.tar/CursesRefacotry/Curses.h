#pragma once
#include <string.h>
#include <vector>
#include <ncurses.h>
#include <string>
#include <iostream>
#include "Paint.h"

using namespace std;

enum eTextPosition
{
    TEXT_NULL = 0x00,
    TEXT_NEXT_X = 0x01,
    TEXT_LEFT_X = 0x02,
    TEXT_CENTER_X = 0x04,
    TEXT_RIGHT_X = 0x08,
    TEXT_NEXT_Y = 0x10,
    TEXT_TOP_Y = 0x20,
    TEXT_MIDDLE_Y = 0x40,
    TEXT_BOTTOM_Y = 0x80,
};

class Curses
{
public:
    Curses();
    virtual ~Curses();

public:
    WINDOW *GetWin();
    bool CreateWin(short h, short w, short x, short y);
    void TouchWin();
    void ClearWin();
    void DestroyWin();
    void GetWH(short &w, short &h);
    void GetXY(short &x, short &y);
    void AddChar(char c);
    void MvAddChar(short x, short y, char c);
    void Print(const char *pFormat, ...);
    void MvPrint(short x, short y, const char *pFormat, ...);
    void AddStr(string s);
    void MvAddStr(short x, short y, string s);
    string GetStr();
    char Scan();
    void CreateBox();
    void DeleteBox();
    void Debug(const char *format, ...);

private:
    WINDOW *mpWin;
    short mbg, mfg;
};