#include <panel.h>
#include <iostream>
#include <map>

using namespace std;

class Panel
{
public:
    Panel();
    ~Panel();

public:
    bool AttachWindow(string id, WINDOW *pWin);
    void TopPanel(string id);
    void BottomPanel(string id);
    void ShowPanel(string id);
    void HidePanel(string id);

private:
    map<string, PANEL *> mPanels;
};
