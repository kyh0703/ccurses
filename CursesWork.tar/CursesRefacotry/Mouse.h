
class Mouse
{
public:
    Mouse(void);
    ~Mouse(void);
};