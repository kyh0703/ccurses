#include "Window.h"

Window::Window()
{
    mPos.h = 0;
    mPos.w = 0;
    mPos.x = 0;
    mPos.y = 0;
    mBorder.ls = ACS_VLINE;
    mBorder.rs = ACS_VLINE;
    mBorder.ts = ACS_HLINE;
    mBorder.bs = ACS_HLINE;
    mBorder.tl = ACS_ULCORNER;
    mBorder.tr = ACS_URCORNER;
    mBorder.bl = ACS_LLCORNER;
    mBorder.br = ACS_LRCORNER;
    mColor.fg = COLOR_WHITE;
    mColor.bg = COLOR_WHITE;
}

Window::~Window()
{
    DestroyWin();
}

void Window::SetRect(short h, short w, short x, short y)
{
    mPos.h = h;
    mPos.w = w;
    mPos.x = x;
    mPos.y = y;
}

void Window::SetColor(short bg, short fg)
{
    mColor.bg = bg;
    mColor.fg = fg;
}

bool Window::Create(void)
{
    mvaddch(mPos.y, mPos.x, mBorder.tl);
    mvaddch(mPos.y, mPos.x + mPos.w, mBorder.tl);
    mvaddch(mPos.y + mPos.);
    mvaddch(mPos.y);
    mvaddch(mPos.y);
    mvaddch(mPos.y);
    mvaddch(mPos.y);
    mvaddch(mPos.y);


    refresh();
    return true;
}

void Window::TouchWin()
{
    touchwin(mpWin);
}

void Window::ClearWin()
{
    werase(mpWin);
}

void Window::DestroyWin()
{
    if (mpWin)
    {
        werase(mpWin);
        delwin(mpWin);
        mpWin = NULL;
    }
}

void Window::GetWH(short &w, short &h)
{
    w = getmaxx(mpWin);
    h = getmaxy(mpWin);
}

void Window::GetXY(short &x, short &y)
{
    getbegyx(mpWin, y, x);
}

void Window::AddChar(char c)
{
    waddch(mpWin, c);
}

void Window::MvAddChar(short x, short y, char c)
{
    mvwaddch(mpWin, y, x, c);
}

void Window::Print(const char *pFormat, ...)
{
    wprintw(mpWin, pFormat);
}

void Window::MvPrint(short x, short y, const char *pFormat, ...)
{
    mvwprintw(mpWin, y, x, pFormat);
}

void Window::AddStr(string s)
{
    waddstr(mpWin, s.c_str());
}

void Window::MvAddStr(short x, short y, string s)
{
    mvwaddstr(mpWin, y, x, s.c_str());
}

string Window::GetStr()
{
    char line[128];
    memset(line, 0x00, sizeof(line));
    wgetstr(mpWin, line);
    return line;
}

char Window::Scan()
{
    char c;
    wscanw(mpWin, &c);
    return c;
}

void Window::CreateBox()
{
    wborder(mpWin, ACS_VLINE, ACS_VLINE,
            ACS_HLINE, ACS_HLINE, ACS_ULCORNER,
            ACS_URCORNER, ACS_LLCORNER, ACS_LRCORNER);
    wrefresh(mpWin);
}

void Window::DeleteBox()
{
    wborder(mpWin, 0, 0, 0, 0, 0, 0, 0, 0);
    wrefresh(mpWin);
}

void Window::Debug(const char *format, ...)
{
    char line[1024], *pPos;
    pPos = line;

    int size = sprintf(pPos, "DEBUG>");
    pPos += size;

    va_list Marker;
    va_start(Marker, format);
    vsnprintf(pPos, sizeof(line - size), format, Marker);
    va_end(Marker);

    mvaddstr(LINES - 1, 0, line);
    refresh();
}