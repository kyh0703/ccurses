#include "Window.h"

Window::Window()
{
    mPos.h = 0;
    mPos.w = 0;
    mPos.x = 0;
    mPos.y = 0;
    mBorder.ls = ACS_VLINE;
    mBorder.rs = ACS_VLINE;
    mBorder.ts = ACS_HLINE;
    mBorder.bs = ACS_HLINE;
    mBorder.tl = ACS_ULCORNER;
    mBorder.tr = ACS_URCORNER;
    mBorder.bl = ACS_LLCORNER;
    mBorder.br = ACS_LRCORNER;
    mColor.fg = COLOR_WHITE;
    mColor.bg = COLOR_BLACK;
}

Window::~Window()
{
}

void Window::SetRect(short h, short w, short x, short y)
{
    mPos.h = h;
    mPos.w = w;
    mPos.x = x;
    mPos.y = y;
}

void Window::SetColor(short bg, short fg)
{
    mColor.bg = bg;
    mColor.fg = fg;
}

void Window::SetTitle(string title)
{
    mTitle = title;
}

bool Window::Create(void)
{
    short colorIdx = Paint::Get().FindIndex(mColor.fg, mColor.bg);
    attron(COLOR_PAIR(colorIdx));
    mvaddch(mPos.y, mPos.x, mBorder.tl);
    mvaddch(mPos.y, mPos.x + mPos.w, mBorder.tr);
    mvaddch(mPos.y + mPos.h, mPos.x, mBorder.bl);
    mvaddch(mPos.y + mPos.h, mPos.x + mPos.w, mBorder.br);
    mvhline(mPos.y, mPos.x + 1, mBorder.ts, mPos.w - 1);
    mvhline(mPos.y + mPos.h, mPos.x + 1, mBorder.bs, mPos.w - 1);
    mvvline(mPos.y + 1, mPos.x, mBorder.ls, mPos.h - 1);
    mvvline(mPos.y + 1, mPos.x + mPos.w, mBorder.rs, mPos.h - 1);
    attroff(COLOR_PAIR(colorIdx));

    if (!mTitle.empty())
        mvaddnstr(mPos.y, mPos.x + 2, mTitle.c_str(), mTitle.size());

    refresh();
    return true;
}

void Window::Clear()
{
    for (int i = mPos.y; i <= mPos.h + mPos.y; ++i)
    {
        for (int j = mPos.x; j <= mPos.x + mPos.w; ++j)
            mvaddch(i, j, ' ');
    }
    refresh();
}