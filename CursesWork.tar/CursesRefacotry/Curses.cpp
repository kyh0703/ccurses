#include "Curses.h"

Curses::Curses()
{
    mpWin = NULL;
}

Curses::~Curses()
{
    DestroyWin();
}

WINDOW *Curses::GetWin()
{
    return mpWin;
}

bool Curses::CreateWin(short h, short w, short x, short y)
{
    mpWin = subwin(stdscr, h, w, y, x);
    if (!mpWin)
        return false;

    wrefresh(mpWin);
    return true;
}

void Curses::TouchWin()
{
    touchwin(mpWin);
}

void Curses::ClearWin()
{
    werase(mpWin);
}

void Curses::DestroyWin()
{
    if (mpWin)
    {
        werase(mpWin);
        delwin(mpWin);
        mpWin = NULL;
    }
}

void Curses::GetWH(short &w, short &h)
{
    w = getmaxx(mpWin);
    h = getmaxy(mpWin);
}

void Curses::GetXY(short &x, short &y)
{
    getbegyx(mpWin, y, x);
}

void Curses::AddChar(char c)
{
    waddch(mpWin, c);
}

void Curses::MvAddChar(short x, short y, char c)
{
    mvwaddch(mpWin, y, x, c);
}

void Curses::Print(const char *pFormat, ...)
{
    wprintw(mpWin, pFormat);
}

void Curses::MvPrint(short x, short y, const char *pFormat, ...)
{
    mvwprintw(mpWin, y, x, pFormat);
}

void Curses::AddStr(string s)
{
    waddstr(mpWin, s.c_str());
}

void Curses::MvAddStr(short x, short y, string s)
{
    mvwaddstr(mpWin, y, x, s.c_str());
}

string Curses::GetStr()
{
    char line[128];
    memset(line, 0x00, sizeof(line));
    wgetstr(mpWin, line);
    return line;
}

char Curses::Scan()
{
    char c;
    wscanw(mpWin, &c);
    return c;
}

void Curses::CreateBox()
{
    wborder(mpWin, ACS_VLINE, ACS_VLINE,
            ACS_HLINE, ACS_HLINE, ACS_ULCORNER,
            ACS_URCORNER, ACS_LLCORNER, ACS_LRCORNER);
    wrefresh(mpWin);
}

void Curses::DeleteBox()
{
    wborder(mpWin, 0, 0, 0, 0, 0, 0, 0, 0);
    wrefresh(mpWin);
}

void Curses::Debug(const char *format, ...)
{
    char line[1024], *pPos;
    pPos = line;

    int size = sprintf(pPos, "DEBUG>");
    pPos += size;

    va_list Marker;
    va_start(Marker, format);
    vsnprintf(pPos, sizeof(line - size), format, Marker);
    va_end(Marker);

    mvaddstr(LINES - 1, 0, line);
    refresh();
}