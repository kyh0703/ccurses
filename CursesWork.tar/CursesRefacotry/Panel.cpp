#include "Panel.h"

Panel::Panel()
{
}

Panel::~Panel()
{
}

bool Panel::AttachWindow(string id, WINDOW *pWin)
{
    PANEL *pPanel = new_panel(pWin);
    if (!pPanel)
    {
        cout << "New Pannel Fail" << endl;
        return false;
    }

    mPanels[id] = pPanel;
    return true;
}

void Panel::TopPanel(string id)
{
    PANEL *pPanel = mPanels[id];
    if (!pPanel)
        return;
    top_panel(pPanel);
}

void Panel::BottomPanel(string id)
{
    PANEL *pPanel = mPanels[id];
    if (!pPanel)
        return;
    bottom_panel(pPanel);
}

void Panel::ShowPanel(string id)
{
    PANEL *pPanel = mPanels[id];
    if (!pPanel)
        return;
    show_panel(pPanel);
}

void Panel::HidePanel(string id)
{
    PANEL *pPanel = mPanels[id];
    if (!pPanel)
        return;
    hide_panel(pPanel);
}