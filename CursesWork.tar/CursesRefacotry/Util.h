#pragma once
#include <ncurses.h>
#include <string.h>
#include <string>

using namespace std;

class Util
{
public:
    Util(void);
    ~Util(void);

    static void Debug(const char *format, ...);
};