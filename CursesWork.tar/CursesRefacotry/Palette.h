#pragma once
#include <locale.h>
#include <ncurses.h>
#include <vector>
#include <string>
#include "Panel.h"
#include "Widget.h"

using namespace std;

class Palette : public Panel
{
public:
    Palette();
    ~Palette();

public:
    void Init(void);
    void AttachWidget(Widget *pWidget);
    bool DrawWidget();

private:
    vector<Widget *> mWidgets;
};
