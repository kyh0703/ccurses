#pragma once
#include <string.h>
#include <vector>
#include <ncurses.h>
#include <string>
#include <iostream>
#include "Paint.h"

using namespace std;

struct Border
{
    chtype ls, rs, ts, bs;
    chtype tl, tr, bl, br;
};

struct Color
{
    short bg, fg;
};

struct Postion
{
    short h, w, x, y;
};

class Window
{
public:
    Window();
    virtual ~Window();

public:
    void SetRect(short h, short w, short x, short y);
    void SetColor(short bg, short fg);
    bool Create(void);
    void ClearWin();
    void DestroyWin();
    void GetWH(short &w, short &h);
    void GetXY(short &x, short &y);
    void AddChar(char c);
    void MvAddChar(short x, short y, char c);
    void Print(const char *pFormat, ...);
    void MvPrint(short x, short y, const char *pFormat, ...);
    void AddStr(string s);
    void MvAddStr(short x, short y, string s);
    string GetStr();
    char Scan();
    void CreateBox();
    void DeleteBox();
    void Debug(const char *format, ...);

private:
    Postion mPos;
    Border mBorder;
    Color mColor;
    WINDOW *mpWin;
};