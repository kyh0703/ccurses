#pragma once
#include <string.h>
#include <vector>
#include <ncurses.h>
#include <string>
#include <iostream>
#include "Paint.h"

using namespace std;

struct Border
{
    chtype ls, rs, ts, bs;
    chtype tl, tr, bl, br;
};

struct Color
{
    short bg, fg;
};

struct Postion
{
    short h, w, x, y;
};

class Window
{
public:
    Window();
    virtual ~Window();

public:
    void SetRect(short h, short w, short x, short y);
    void SetColor(short bg, short fg);
    void SetTitle(string title);
    bool Create(void);
    void Clear();

private:
    Postion mPos;
    Border mBorder;
    Color mColor;
    string mTitle;
};