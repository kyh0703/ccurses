#include "Painter.h"

Painter *Painter::instance = NULL;

Painter::Painter(void)
{
    mnColorCount = 0;
    memset(mstColorTable, 0x00, sizeof(mstColorTable));
}

Painter::~Painter(void)
{
}

Painter *Painter::GetInstance(void)
{
    if (!instance)
        instance = new Painter;

    return instance;
}

void Painter::DestroyInstance(void)
{
    if (instance)
    {
        delete instance;
        instance = NULL;
    }
}

bool Painter::IsColorSet(short nForgroundColor, short nBackgroundColor)
{
    switch (nForgroundColor)
    {
    case COLOR_BLACK:
    case COLOR_RED:
    case COLOR_GREEN:
    case COLOR_YELLOW:
    case COLOR_BLUE:
    case COLOR_MAGENTA:
    case COLOR_CYAN:
    case COLOR_WHITE:
        break;
    default:
        return false;
    }

    switch (nBackgroundColor)
    {
    case COLOR_BLACK:
    case COLOR_RED:
    case COLOR_GREEN:
    case COLOR_YELLOW:
    case COLOR_BLUE:
    case COLOR_MAGENTA:
    case COLOR_CYAN:
    case COLOR_WHITE:
        break;
    default:
        return false;
    }

    return true;
}

short Painter::FindIndex(short nForgroundColor, short nBackgroundColor)
{
    short nIndex = FindColorSet(nForgroundColor, nBackgroundColor);
    if (nIndex <= 0)
    {
        nIndex = AppendColorSet(nForgroundColor, nBackgroundColor);
        if (nIndex <= 0)
            return 0;
    }

    return nIndex;
}

short Painter::FindColorSet(short nForgroundColor, short nBackgroundColor)
{
    for (int nColor = 0; nColor < mnColorCount; nColor++)
    {
        if ((mstColorTable[nColor].nForgroundColor == nForgroundColor) && (mstColorTable[nColor].nBackgroundColor == nBackgroundColor))
            return mstColorTable[nColor].nNo;
    }

    return -1;
}

short Painter::AppendColorSet(short nForgroundColor, short nBackgroundColor)
{
    short nResult = FindColorSet(nForgroundColor, nBackgroundColor);
    if (nResult > 0)
        return nResult;

    if (mnColorCount >= 64)
        return -1;

    mstColorTable[mnColorCount].nNo = mnColorCount + 1;
    mstColorTable[mnColorCount].nForgroundColor = nForgroundColor;
    mstColorTable[mnColorCount].nBackgroundColor = nBackgroundColor;

    if (mnColorCount <= 0)
        start_color();

    init_pair(mstColorTable[mnColorCount].nNo, mstColorTable[mnColorCount].nForgroundColor, mstColorTable[mnColorCount].nBackgroundColor);
    nResult = mstColorTable[mnColorCount].nNo;

    mnColorCount++;
    return nResult;
}

bool Painter::SetWindowColor(WINDOW *pWindow, short nForgroundColor, short nBackgroundColor)
{
    if (!pWindow)
        return false;

    if (!IsColorSet(nForgroundColor, nBackgroundColor))
        return false;

    short nIndex = FindIndex(nForgroundColor, nBackgroundColor);
    wbkgd(pWindow, COLOR_PAIR(nIndex));
    wrefresh(pWindow);
    return true;
}

bool Painter::SetFieldColor(FIELD *pField, short nForgroundColor, short nBackgroundColor)
{
    if (!pField)
        return false;

    if (!IsColorSet(nForgroundColor, nBackgroundColor))
        return false;

    short nIndex = FindIndex(nForgroundColor, nBackgroundColor);
    set_field_fore(pField, COLOR_PAIR(nIndex));
    set_field_back(pField, COLOR_PAIR(nIndex));
    return true;
}

bool Painter::SetMenuColor(MENU *pMenu, short nType, short nForgroundColor, short nBackgroundColor)
{
    if (!pMenu)
        return false;

    if (!IsColorSet(nForgroundColor, nBackgroundColor))
        return false;

    short nIndex = FindIndex(nForgroundColor, nBackgroundColor);
    switch (nType)
    {
    case eMenuColorSet_Disable:
        set_menu_grey(pMenu, COLOR_PAIR(nIndex));
        break;
    case eMenuColorSet_Cursor:
        set_menu_fore(pMenu, COLOR_PAIR(nIndex) | A_REVERSE);
        break;
    case eMenuColorSet_Default:
        set_menu_back(pMenu, COLOR_PAIR(nIndex));
        break;
    default:
        return false;
    }

    return true;
}
