
/**
 * @brief
 * https://wiki.kldp.org/wiki.php/NCURSES-Programming-HOWTO
 * Curses 해당 내용 참고.
 */
#include <ncurses.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "BasicWindow.h"
#include "FormWindow.h"
#include "MenuWindow.h"
#include "Screen.h"

Screen theScreen;
FormWindow formWindow;
MenuWindow menuWindow;
BasicWindow basicWindow;
BasicWindow TitleWindow;

bool ViewFormWindow(void);
bool ViewMenuWindow(void);
void ViewBasicWindow(void);

void ExitService(int nSignal)
{
    switch (nSignal)
    {
    default:
    case SIGHUP:
    case SIGQUIT:
    case SIGALRM:
    case SIGPIPE:
    case SIGCHLD:
        break;
    case SIGKILL:
    case SIGTERM:
    case SIGINT:
        theScreen.DestroyScreen();
        usleep(1000000);
        _exit(99);
        break;
    }
}

void InitSignal(void)
{
    signal(SIGHUP, SIG_IGN);
    signal(SIGQUIT, ExitService);
    signal(SIGINT, ExitService);
    signal(SIGTERM, ExitService);
    signal(SIGKILL, ExitService);
    signal(SIGALRM, ExitService);
    signal(SIGPIPE, ExitService);
    signal(SIGCHLD, ExitService);
}

void TestForm(int nField, int nKeyEvent, const char *sValue)
{
    switch (nKeyEvent)
    {
    case KEY_F(1):
        formWindow.SetRun(false);
        exit(1);
        break;
    case 10:
        char sBuf[4096];
        memset(sBuf, 0x00, sizeof(sBuf));
        formWindow.GetFieldBuffer(0, sBuf);
        break;
    case KEY_RESIZE:
        formWindow.Destroy();
        ViewFormWindow();
        break;
    case KEY_F(2):
        formWindow.DeleteLine();
        break;
    }
}

void TestMenu(int nItems, int nKeyEvent, const char *sValue)
{
    switch (nKeyEvent)
    {
    case KEY_F(1):
        menuWindow.Destroy();
        exit(1);
        break;
    case 10:
        break;
    case KEY_RESIZE:
        TitleWindow.Destroy();
        basicWindow.Destroy();
        menuWindow.Destroy();
        ViewBasicWindow();
        ViewMenuWindow();
        break;
    }
}

bool ViewMenuWindow(void)
{
    WindowAttribute attr{
        false, 10, 10, 10, 15, 1, 1,
        COLOR_BLACK,
        COLOR_BLUE};
    menuWindow.CreateItem("test1");
    menuWindow.SetAttribute(attr);
    if (!menuWindow.CreateMenu())
        return false;
    menuWindow.SetMenuFormat(1, 5);
    menuWindow.SetVisibleDesc(true);
    menuWindow.SetMultiSelect(false);
    menuWindow.SetMenuMark(" > ");
    menuWindow.SetMenuColor(0, COLOR_BLACK, COLOR_BLUE);
    menuWindow.SetMenuColor(1, COLOR_RED, COLOR_BLUE);
    menuWindow.SetMenuColor(2, COLOR_WHITE, COLOR_BLUE);
    if (!menuWindow.CreateWindow())
        return false;

    menuWindow.MoveCursor("test3");
    menuWindow.MoveCursor("test2");
    menuWindow.Run(std::bind(&TestMenu, std::placeholders::_1, std::placeholders::_2, std::placeholders::_3));
    return true;
}

bool ViewFormWindow(void)
{
    WindowAttribute WindowAttribute;
    // WindowAttribute.SetBoxYn(true);
    // WindowAttribute.SetBeginX(0);
    // WindowAttribute.SetBeginY(0);
    // WindowAttribute.SetX(COLS);
    // WindowAttribute.SetY(LINES);
    // WindowAttribute.SetMarginX(1);
    // WindowAttribute.SetMarginY(1);
    // WindowAttribute.SetForgroundColor(COLOR_BLACK);
    // WindowAttribute.SetBackgroundColor(COLOR_BLUE);
    formWindow.SetAttribute(WindowAttribute);
    formWindow.SetField("Node ID              :", 1);
    formWindow.SetField("SWAT IP              :", 14);
    formWindow.SetField("ID IP                :", 14);
    if (!formWindow.CreateFields())
        return false;

    formWindow.SetFieldTypeIpv4(1);
    formWindow.SetFieldsColor(COLOR_RED, COLOR_BLACK);
    if (!formWindow.CreateForm())
        return false;

    if (!formWindow.CreateWindow())
        return false;

    formWindow.Run(std::bind(&TestForm, std::placeholders::_1, std::placeholders::_2, std::placeholders::_3));
    return true;
}

void ViewBasicWindow(void)
{
    // Screen
    WindowAttribute windowAttribute;
    // windowAttribute.SetBoxYn(false);
    // windowAttribute.SetBeginX(0);
    // windowAttribute.SetBeginY(0);
    // windowAttribute.SetX(COLS);
    // windowAttribute.SetY(LINES);
    // windowAttribute.SetForgroundColor(COLOR_WHITE);
    // windowAttribute.SetBackgroundColor(COLOR_BLACK);
    basicWindow.SetAttribute(windowAttribute);
    if (!basicWindow.CreateWindow())
        return;
    basicWindow.Print(TEXT_LEFT_X, A_BOLD, "test11");
    // Title
    // windowAttribute.SetBoxYn(true);
    // windowAttribute.SetBeginX(COLS/2);
    // windowAttribute.SetBeginY(LINES/2);
    // windowAttribute.SetX(50);
    // windowAttribute.SetY(50);
    // windowAttribute.SetForgroundColor(COLOR_BLUE);
    // windowAttribute.SetBackgroundColor(COLOR_WHITE);
    TitleWindow.SetAttribute(windowAttribute);
    if (!TitleWindow.CreateWindow())
        return;
    TitleWindow.Print(TEXT_CENTER_X | TEXT_NEXT_Y, A_DIM | A_UNDERLINE, "test1");
}

int main(void)
{
    theScreen.CreateScreen();
    ViewBasicWindow();
    // ViewFormWindow();
    ViewMenuWindow();
}
