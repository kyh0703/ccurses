#pragma once
#include <ncurses.h>
#include <form.h>
#include <menu.h>
#include <string.h>

enum
{
    eMenuColorSet_Disable,
    eMenuColorSet_Cursor,
    eMenuColorSet_Default,
};

typedef struct
{
    short nNo;
    short nForgroundColor;
    short nBackgroundColor;
} COLOR_TABLE;

class Painter
{
private:
    Painter(void);
    Painter(const Painter &other);
    ~Painter(void);

public:
    static Painter *GetInstance(void);
    static void DestroyInstance(void);

    bool IsColorSet(short forgroundColor, short backgroundColor);
    short FindIndex(short forgroundColor, short backgroundColor);
    short AppendColorSet(short forgroundColor, short backgroundColor);
    short FindColorSet(short forgroundColor, short backgroundColor);
    bool SetWindowColor(WINDOW *pWindow, short forgroundColor, short backgroundColor);
    bool SetFieldColor(FIELD *pField, short borgroundColor, short backgroundColor);
    bool SetMenuColor(MENU *pMenu, short type, short forgroundColor, short backgroundColor);

private:
    int mnColorCount;
    COLOR_TABLE mstColorTable[64];
    static Painter *instance;
};
