#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include <ncurses.h>
#include <form.h>
#include <functional>
#include <iLib.h>
#include "Painter.h"
#include "WindowAttribute.h"

#define MAXLEN_FEILDNAME 50
typedef std::function<void(int, int, const char *)> pFormCB;

typedef struct
{
    const char *sField;
    int nFieldMaxLen;
    int nFieldNameMaxLen;
    int nFieldHeight;
} _FIELD;

/**
 * @brief
 * XXX CURSES 제공 변수
 * COLS: Screen Max X Size
 * LINES: Screen Max Y Size
 * KEY_RESIZE: Resize Window
 * Example)
 *     COLSS / 2 - begin_x
 *     LINES / 2 - begin_y
 */
class FormWindow
{
public:
    FormWindow(void);
    virtual ~FormWindow(void);

    void SetAttribute(WindowAttribute &windowAttribute);
    bool SetField(const char *sField, int nFieldMaxLen, int nFieldHeight = 1);
    bool CreateFields(void);
    const char *GetFieldBuffer(int nField, char *sField);
    void SetFieldOption(int nField, bool bIsOn, unsigned int nFieldOptions);
    void SetFieldsOption(bool bIsOn, unsigned int nFieldOptions);
    void SetFieldDefaultValue(int nField, const char *sBuffer);
    void SetFieldColor(int nField, short nForgroundColor, short nBackgroundColor);
    void SetFieldsColor(short nForgroundColor, short nBackgroundColor);
    void SetFieldBack(int nField, unsigned int nFieldBack);
    void SetFieldsBack(unsigned int nFieldBack);
    void SetFieldTypeAlpha(int nField, int nWidth = 0);
    void SetFieldTypeAlNum(int nField, int nWidth = 0);
    void SetFieldTypeInt(int nField, int nPadding, int nValidMin = 0, int nValidMax = 0);
    void SetFieldTypeIpv4(int nField);
    void SetFieldTypeIpv6(int nField);
    void SetFieldTypeRegexp(int nField, char *sRegexp);
    bool CreateForm(void);
    bool CreateWindow(void);
    void Destroy(void);
    void DestroyFields(void);
    void DestroyForm(void);
    void DestroyWindow(void);
    void SetRun(bool bRun);
    bool IsRun(void);
    void Run(pFormCB pFunction);
    void DefaultKeyAction(int nChar);
    void DeleteLine(void);
    void MovePrevLine(void);
    void MoveNextLine(void);

private:
    bool mbRun;
    WINDOW *mpWindow;
    FORM *mpForm;
    pFormCB mpCB;
    WindowAttribute mWindowAttribute;
    std::vector<FIELD *> mpFields;
    std::vector<_FIELD> mstFields;
};
