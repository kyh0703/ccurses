#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <ncurses.h>
#include <iostream>
#include <menu.h>
#include <functional>
#include <vector>
#include <iLib.h>
#include "Painter.h"

#define MENU_TOKEN "/"
typedef std::function<void(int, int, const char *)> pMenuCB;

/**
 * @brief
 * XXX CURSES 제공 변수
 * COLS: Screen Max X Size
 * LINES: Screen Max Y Size
 * KEY_RESIZE: Resize Window
 */
class MenuWindow
{
public:
    MenuWindow(void);
    virtual ~MenuWindow(void);

private:
    void DefaultKeyAction(int nChar);
    void DestroyItem(void);
    void DestroyMenu(void);
    void DestroyWindow(void);

public:
    // void SetAttribute(WindowAttribute &windowAttribute);
    bool CreateItem(const char *sField, const char *sDesc = NULL);
    bool CreateMenu(void);
    void SetMultiSelect(bool bMulti);
    void SetVisibleDesc(bool bDesc);
    void SetMenuFormat(int nItemRow, int nYItemCols);
    void SetMenuMark(const char *sMark);
    void SetMenuColor(short nType, short nForgroundColor, short nBackgroundColor);
    bool CreateWindow(void);
    void Destroy(void);
    void Run(pMenuCB pFunction);
    bool MoveLeft(void);
    bool MoveRight(void);
    bool MoveUp(void);
    bool MoveDown(void);
    bool MoveCursor(NPCSTR sMenuItem);
    bool GetCurrentCursorItem(NPSTR sItem);

private:
    bool mbRun;
    bool mbMultiSelect;
    MENU *mpMenu;
    WINDOW *mpWindow;
    pMenuCB mpCB;
    // WindowAttribute mWindowAttribute;
    std::vector<ITEM *> mpItems;
};
