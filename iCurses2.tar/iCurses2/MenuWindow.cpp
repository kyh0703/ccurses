#include "MenuWindow.h"

MenuWindow::MenuWindow(void)
{
    mbRun = false;
    mbMultiSelect = false;
    mpMenu = NULL;
    mpWindow = NULL;
    mpCB = NULL;
}

MenuWindow::~MenuWindow(void)
{
    Destroy();
}

void MenuWindow::DefaultKeyAction(int nChar)
{
    switch (nChar)
    {
    case KEY_LEFT:
        menu_driver(mpMenu, REQ_LEFT_ITEM);
        break;
    case KEY_RIGHT:
        menu_driver(mpMenu, REQ_RIGHT_ITEM);
        break;
    case KEY_UP:
        menu_driver(mpMenu, REQ_UP_ITEM);
        break;
    case KEY_DOWN:
        menu_driver(mpMenu, REQ_DOWN_ITEM);
        break;
    case KEY_NPAGE:
        menu_driver(mpMenu, REQ_SCR_DPAGE);
        break;
    case KEY_PPAGE:
        menu_driver(mpMenu, REQ_SCR_UPAGE);
        break;
    case ' ':
        if (mbMultiSelect)
            menu_driver(mpMenu, REQ_TOGGLE_ITEM);
        break;
    default:
        break;
    }
}

void MenuWindow::DestroyItem(void)
{
    for (std::vector<ITEM *>::size_type nItem = 0; nItem < mpItems.size(); nItem++)
    {
        if (!mpItems[nItem])
            continue;

        free_item(mpItems[nItem]);
        mpItems[nItem] = NULL;
    }

    mpItems.clear();
}

void MenuWindow::DestroyMenu(void)
{
    if (!stdscr)
        return;
    if (!mpMenu)
        return;

    // unpost_menu(mpMenu);
    free_menu(mpMenu);
    mpMenu = NULL;
}

void MenuWindow::DestroyWindow(void)
{
    if (!stdscr)
        return;
    if (!mpWindow)
        return;

    // if (mWindowAttribute.IsBox())
        // wborder(mpWindow, ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ');

    werase(mpWindow);
    delwin(mpWindow);
    mpWindow = NULL;
}

// void MenuWindow::SetAttribute(WindowAttribute &windowAttribute)
// {
    // mWindowAttribute = windowAttribute;
// }

bool MenuWindow::CreateItem(const char *sItem, const char *sDesc)
{
    if (!stdscr)
        return false;
    if (mpMenu)
        return false;
    if (mpWindow)
        return false;

    ITEM *pItem = new_item(sItem, sDesc);
    if (!pItem)
        return false;

    if (mpItems.empty())
        mpItems.push_back(pItem);
    else
        mpItems[mpItems.size() - 1] = pItem;

    mpItems.push_back(NULL);
    return true;
}

bool MenuWindow::CreateMenu(void)
{
    if (!stdscr)
        return false;
    if (mpItems.empty())
        return false;

    mpMenu = new_menu(mpItems.data());
    return (mpMenu ? true : false);
}

void MenuWindow::SetMultiSelect(bool bMulti)
{
    if (!stdscr)
        return;
    if (!mpMenu)
        return;

    if (bMulti)
    {
        menu_opts_off(mpMenu, O_ONEVALUE);
        mbMultiSelect = true;
    }
    else
    {
        menu_opts_on(mpMenu, O_ONEVALUE);
        mbMultiSelect = false;
    }
}

void MenuWindow::SetVisibleDesc(bool bDesc)
{
    if (!stdscr)
        return;
    if (!mpMenu)
        return;

    if (bDesc)
        menu_opts_on(mpMenu, O_SHOWDESC);
    else
        menu_opts_off(mpMenu, O_SHOWDESC);
}

void MenuWindow::SetMenuFormat(int nItemRow, int nYItemCols)
{
    if (!stdscr)
        return;
    if (!mpMenu)
        return;

    set_menu_format(mpMenu, nItemRow, nYItemCols);
}

void MenuWindow::SetMenuMark(const char *sMark)
{
    if (!stdscr)
        return;
    if (!mpMenu)
        return;

    set_menu_mark(mpMenu, sMark);
}

void MenuWindow::SetMenuColor(short nType, short nForgroundColor, short nBackgroundColor)
{
    if (!stdscr)
        return;
    if (!mpMenu)
        return;

    Painter::GetInstance()->SetMenuColor(mpMenu, nType, nForgroundColor, nBackgroundColor);
}

bool MenuWindow::CreateWindow(void)
{
    if (!stdscr)
        return false;
    if (mpItems.empty())
        return false;
    if (!mpMenu)
        return false;
    if (mpWindow)
        return false;

    int nMenuY, nMenuX;
    scale_menu(mpMenu, &nMenuY, &nMenuX);
    // if (mWindowAttribute.GetX() != 0)
    // {
        // if (mWindowAttribute.GetX() < nMenuX)
            // return false;
    // }

    // if (mWindowAttribute.GetY() != 0)
    // {
        // if (mWindowAttribute.GetY() < nMenuY)
            // return false;
    // }

    // mpWindow = newwin(mWindowAttribute.GetY(), mWindowAttribute.GetX(),
                    //   mWindowAttribute.GetBeginY(), mWindowAttribute.GetBeginX());
    // if (!mpWindow)
        // return false;

    // Painter::GetInstance()->SetWindowColor(mpWindow,
                                        //    mWindowAttribute.GetForgroundColor(),
                                        //    mWindowAttribute.GetBackgroundColor());

    set_menu_win(mpMenu, mpWindow);
    // set_menu_sub(mpMenu, derwin(mpWindow, nMenuY, nMenuX, mWindowAttribute.GetMarginY(), mWindowAttribute.GetMarginX()));

    // if (mWindowAttribute.IsBox())
        // wborder(mpWindow, 0, 0, 0, 0, 0, 0, 0, 0);

    post_menu(mpMenu);
    wrefresh(mpWindow);
    return true;
}

void MenuWindow::Destroy(void)
{
    mbRun = false;
    DestroyWindow();
    DestroyMenu();
    DestroyItem();
}


void MenuWindow::Run(pMenuCB pFunction)
{
    if (!stdscr)
        return;
    if (!mpWindow)
        return;
    if (!mpMenu)
        return;

    mpCB = std::move(pFunction);
    mbRun = true;

    keypad(mpWindow, TRUE);
    while (mbRun)
    {
        int nChar = wgetch(mpWindow);
        DefaultKeyAction(nChar);
        if (mbMultiSelect)
        {
            char sTemp[4096];
            memset(sTemp, 0x00, sizeof(sTemp));
            ITEM **items = menu_items(mpMenu);
            for (int nItem = 0; nItem < item_count(mpMenu); nItem++)
            {
                if (item_value(items[nItem]) == TRUE)
                {
                    char sItem[1024];
                    memset(sItem, 0x00, sizeof(sItem));
                    iStrCpy(sItem, item_name(items[nItem]));
                    iTrim(sItem);
                    strcat(sTemp, sItem);
                    strcat(sTemp, "/");
                }
            }

            mpCB(0, nChar, sTemp);
            pos_menu_cursor(mpMenu);
        }
        else
        {
            ITEM *pCurrentItem = current_item(mpMenu);
            char sItem[1024];
            memset(sItem, 0x00, sizeof(sItem));
            iStrCpy(sItem, item_name(pCurrentItem));
            iTrim(sItem);
            mpCB(item_index(pCurrentItem), nChar, sItem);
            pos_menu_cursor(mpMenu);
        }
    }
}

bool MenuWindow::MoveLeft(void)
{
    if (!mpMenu)
        return false;

    if (menu_driver(mpMenu, REQ_LEFT_ITEM) != E_OK)
        return false;

    return true;
}

bool MenuWindow::MoveRight(void)
{
    if (!mpMenu)
        return false;

    if (menu_driver(mpMenu, REQ_RIGHT_ITEM) != E_OK)
        return false;

    return true;
}

bool MenuWindow::MoveUp(void)
{
    if (!mpMenu)
        return false;

    if (menu_driver(mpMenu, REQ_UP_ITEM) != E_OK)
        return false;

    return true;
}

bool MenuWindow::MoveDown(void)
{
    if (!mpMenu)
        return false;

    if (menu_driver(mpMenu, REQ_DOWN_ITEM) != E_OK)
        return false;

    return true;
}

bool MenuWindow::MoveCursor(NPCSTR sMenuItem)
{
    if (!mpMenu)
        return false;

    if (menu_driver(mpMenu, REQ_CLEAR_PATTERN) != E_OK)
        return false;

    if (set_menu_pattern(mpMenu, sMenuItem) != E_OK)
        return false;

    return true;
}

bool MenuWindow::GetCurrentCursorItem(NPSTR sItem)
{
    if (!mpMenu)
        return false;

    ITEM *pCurrentItem = current_item(mpMenu);
    if (!pCurrentItem)
        return false;

    char sBuffer[1024];
    iStrCpy(sBuffer, item_name(pCurrentItem));
    iTrim(sBuffer);
    iStrCpy(sItem, sBuffer);
    return true;
}
